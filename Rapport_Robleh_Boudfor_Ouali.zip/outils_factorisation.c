// outils de factorisation : Deuxième partie du projet 

//on ajoute le bibiliothèque functions.h qui contient tous les fonction nécessaire pour appeler les fonctions necessaires

#include "functions.h"  
#define INITIAL_CAPACITE 10

int main(void) {
    //Lecture du nombre à factoriser
    mpz_t n;
    mpz_init(n);
    char input_str[1024];
    printf("Entrer le nombre n à factoriser : ");
    if (scanf("%1023s", input_str) != 1) {
        fprintf(stderr, "Erreur lors de la lecture.\n");
        mpz_clear(n);
        return EXIT_FAILURE;
    }
    if (mpz_set_str(n, input_str, 10) != 0) {
        fprintf(stderr, "Entrée invalide pour n.\n");
        mpz_clear(n);
        return EXIT_FAILURE;
    }

    // Initialisation des tableaux dynamiques pour stocker les facteurs et leurs puissances
    size_t capacite_facteurs = INITIAL_CAPACITE;
    size_t taille_facteurs = 0;
    mpz_t *liste_facteurs = malloc(capacite_facteurs * sizeof(mpz_t));
    mpz_t *liste_puissances = malloc(capacite_facteurs * sizeof(mpz_t));
    if (!liste_facteurs || !liste_puissances) {
        fprintf(stderr, "Erreur d'allocation mémoire.\n");
        mpz_clear(n);
        return EXIT_FAILURE;
    }
    for (size_t i = 0; i < capacite_facteurs; i++) {
        mpz_init(liste_facteurs[i]);
        mpz_init(liste_puissances[i]);
    }

    //Copie modifiable de n pour le reste à factoriser
    mpz_t n_restant;
    mpz_init_set(n_restant, n);

    int choix_menu;
    do {
        // Affichage de l'état actuel
        gmp_printf("\n==> Nombre restant à factoriser : %Zd\n", n_restant);
        if (taille_facteurs > 0) {
            printf("Facteurs trouvés jusqu'à présent :\n");
            for (size_t i = 0; i < taille_facteurs; i++) {
                gmp_printf("   %Zd^%Zd\n", liste_facteurs[i], liste_puissances[i]);
            }
        } else {
            printf("Aucun facteur trouvé jusqu'à présent.\n");
        }

        /*  
         * Test de primalité sur le nombre restant.
         * S'il est premier (et différent de 1), on l'ajoute directement à la liste,
         * et la factorisation est considérée comme complète.
         */
        if (mpz_cmp_ui(n_restant, 1) != 0 && test_miller_rabin(n_restant)) {
            printf("\nLe nombre restant est premier.\n");
            ajouter_facteur_avec_exposant(n_restant, 1,
                &liste_facteurs, &liste_puissances, &taille_facteurs, &capacite_facteurs);
            
            printf("\nFactorisation complète : ");
            for (size_t i = 0; i < taille_facteurs; i++) {
                gmp_printf("%Zd^%Zd", liste_facteurs[i], liste_puissances[i]);
                if (i < taille_facteurs - 1)
                    printf(" * ");
            }
            printf("\n");
            break;  
        }

        // Calcul du produit des facteurs trouvés (pour vérifier si la factorisation est complète)
        {
            mpz_t product;
            mpz_init_set_ui(product, 1);
            for (size_t i = 0; i < taille_facteurs; i++) {
                mpz_t factor_power;
                mpz_init(factor_power);
                mpz_pow_ui(factor_power, liste_facteurs[i], mpz_get_ui(liste_puissances[i]));
                mpz_mul(product, product, factor_power);
                mpz_clear(factor_power);
            }
            if (mpz_cmp(product, n) == 0) {
                printf("\nFactorisation complète : ");
                for (size_t i = 0; i < taille_facteurs; i++) {
                    gmp_printf("%Zd^%Zd", liste_facteurs[i], liste_puissances[i]);
                    if (i < taille_facteurs - 1)
                        printf(" * ");
                }
                printf("\n");
                mpz_clear(product);
                break;
            }
            mpz_clear(product);
        }

        // Interface utilisateur : choix de la méthode
        printf("\nChoisissez la méthode de factorisation :\n");
        printf("  1 - Division successive\n");
        printf("  2 - Pollard Rho (et variantes)\n");
        printf("  3 - Pollard p-1 (ALL_FACTORS)\n");
        printf("  0 - Quitter\n");
        printf("Votre choix : ");
        if (scanf("%d", &choix_menu) != 1) {
            fprintf(stderr, "Erreur de lecture du choix.\n");
            break;
        }

        switch (choix_menu) {
            case 1: {
                // Méthode 1 : Division successive
                mpz_t p_max;
                mpz_init(p_max);
                printf("Entrer la valeur de p_max (max 10^4) : ");
                char pmax_str[1024];
                if (scanf("%1023s", pmax_str) != 1) {
                    fprintf(stderr, "Erreur de lecture pour p_max.\n");
                    mpz_clear(p_max);
                    break;
                }
                if (mpz_set_str(p_max, pmax_str, 10) != 0) {
                    fprintf(stderr, "Entrée invalide pour p_max.\n");
                    mpz_clear(p_max);
                    break;
                }
                // Vérification : si p_max > 10^4 alors on force p_max = 10^4
                {
                    mpz_t limit;
                    mpz_init_set_str(limit, "10000", 10);
                    if (mpz_cmp(p_max, limit) > 0) {
                        printf("La valeur entrée dépasse 10^4. Utilisation de 10^4.\n");
                        mpz_set(p_max, limit);
                    }
                    mpz_clear(limit);
                }
                clock_t start = clock();
                Divisions(n_restant, p_max, liste_facteurs, liste_puissances,
                    &taille_facteurs, &capacite_facteurs);
                clock_t end = clock();
                double cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
                printf("Temps d'exécution (Divisions successives) : %.6f secondes\n", cpu_time_used);
                mpz_clear(p_max);
                break;
            }
            case 2: {
                // Méthode 2 : Pollard Rho et variantes
                printf("Choisissez la variante :\n");
                printf("  1 - Pollard Rho basique\n");
                printf("  2 - Pollard Rho-Floyd (tortue/lièvre)\n");
                printf("  3 - Brent\n");
                printf("Votre choix : ");
                int variante;
                if (scanf("%d", &variante) != 1) {
                    fprintf(stderr, "Erreur de lecture pour la variante.\n");
                    break;
                }
                int found = 0;
                mpz_t factor;
                mpz_init(factor);
                if (variante == 1 || variante == 2) {
                    mpz_t c;
                    mpz_init(c);
                    printf("Entrer la valeur de c : ");
                    char c_str[1024];
                    if (scanf("%1023s", c_str) != 1) {
                        fprintf(stderr, "Erreur de lecture pour c.\n");
                        mpz_clear(c);
                        break;
                    }
                    if (mpz_set_str(c, c_str, 10) != 0) {
                        fprintf(stderr, "Entrée invalide pour c.\n");
                        mpz_clear(c);
                        break;
                    }
                    unsigned long max_iter;
                    printf("Entrer le nombre maximum d'itérations (10^16): ");
                    if (scanf("%lu", &max_iter) != 1) {
                        fprintf(stderr, "Erreur de lecture pour max_iter.\n");
                        mpz_clear(c);
                        break;
                    }
                    // Vérification : si max_iter > 10^16, on le force à 10^16
                    {
                        unsigned long max_limit = 10000000000000000UL; // 10^16
                        if (max_iter > max_limit) {
                            printf("La valeur de max_iter dépasse 10^16. Utilisation de 10^16.\n");
                            max_iter = max_limit;
                        }
                    }
                    unsigned long success_count = 0, total_attempts = 0;
                    clock_t start = clock();
                    if (variante == 1)
                        found = rho_pollard(factor, n_restant, c, max_iter, &success_count, &total_attempts);
                    else
                        found = rho_pollard_floyd(factor, n_restant, c, max_iter, &success_count, &total_attempts);
                    clock_t end = clock();
                    double cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
                    printf("Temps d'exécution (Pollard Rho) : %.6f secondes\n", cpu_time_used);
                    mpz_clear(c);
                } else if (variante == 3) {
                    unsigned long iter_max, x0;
                    printf("Entrer iter_max (max 10^16) : ");
                    if (scanf("%lu", &iter_max) != 1) {
                        fprintf(stderr, "Erreur de lecture pour iter_max.\n");
                        break;
                    }
                    // Vérification pour Brent : si iter_max > 10^16, le forcer à 10^16
                    {
                        unsigned long max_limit = 10000000000000000UL; // 10^16
                        if (iter_max > max_limit) {
                            printf("La valeur de iter_max dépasse 10^16. Utilisation de 10^16.\n");
                            iter_max = max_limit;
                        }
                    }
                    printf("Entrer x0 : ");
                    if (scanf("%lu", &x0) != 1) {
                        fprintf(stderr, "Erreur de lecture pour x0.\n");
                        break;
                    }
                    clock_t start = clock();
                    brent_factorization(factor, n_restant, iter_max, x0);
                    clock_t end = clock();
                    double cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
                    printf("Temps d'exécution (Brent) : %.6f secondes\n", cpu_time_used);
                } else {
                    printf("Variante inconnue.\n");
                    mpz_clear(factor);
                    break;
                }
                // Si un facteur non trivial a été trouvé, on le retire de n_restant et on l'ajoute à la liste.
                if (found || (mpz_cmp_ui(factor, 0) != 0)) {
                    gmp_printf("Facteur trouvé : %Zd\n", factor);
                    unsigned long exposant = 0;
                    while (mpz_divisible_p(n_restant, factor)) {
                        mpz_divexact(n_restant, n_restant, factor);
                        exposant++;
                    }
                    ajouter_facteur_avec_exposant(factor, exposant,
                        &liste_facteurs, &liste_puissances, &taille_facteurs, &capacite_facteurs);
                } else {
                    printf("Aucun facteur non trivial n'a été trouvé avec cette méthode.\n");
                }
                mpz_clear(factor);
                break;
            }
            case 3: {
                // Méthode 3 : Pollard p-1 via all_factors
                /*
                Remarque  : Les bornes B1 et B2 sont lues en tant qu'unsigned long qui est environ 1.8×10^19, bien en-deçà de 10^36. Ainsi, ici, on ne peut pas forcer une valeur maximale de 10^36 .
                */
                unsigned long B1, B2;
                printf("Entrer la borne B1  : ");
                if (scanf("%lu", &B1) != 1) {
                    fprintf(stderr, "Erreur de lecture pour B1.\n");
                    break;
                }
                printf("Entrer la borne B2 : ");
                if (scanf("%lu", &B2) != 1) {
                    fprintf(stderr, "Erreur de lecture pour B2.\n");
                    break;
                }
                if (B2 < B1) {
                    printf("Erreur : B2 doit être supérieur ou égal à B1.\n");
                    break;
                }
                int max_factors = 100;  /
                int count = 0;
                mpz_t *temp_factors = malloc(max_factors * sizeof(mpz_t));
                if (!temp_factors) {
                    fprintf(stderr, "Erreur d'allocation mémoire pour temp_factors.\n");
                    break;
                }
                for (int i = 0; i < max_factors; i++) {
                    mpz_init(temp_factors[i]);
                }
                struct timespec ts_start, ts_end;
                clock_gettime(CLOCK_MONOTONIC, &ts_start);
                all_factors(n_restant, temp_factors, &count, B1, B2);
                clock_gettime(CLOCK_MONOTONIC, &ts_end);
                double elapsed_sec = ts_end.tv_sec - ts_start.tv_sec;
                double elapsed_nsec = ts_end.tv_nsec - ts_start.tv_nsec;
                double total_time = elapsed_sec + elapsed_nsec / 1e9;
                
                // Ajout de chaque facteur trouvé dans la liste globale 
                for (int i = 0; i < count; i++) {
                    ajouter_facteur_avec_exposant(temp_factors[i], 1,
                        &liste_facteurs, &liste_puissances, &taille_facteurs, &capacite_facteurs);
                }
                printf("Temps d'exécution (Pollard p-1 ALL_FACTORS) : %.6f secondes\n", total_time);
                
                for (int i = 0; i < count; i++) {
                    mpz_clear(temp_factors[i]);
                }
                free(temp_factors);
                break;
            }
            case 0:
                printf("Fin de la factorisation interactive.\n");
                break;
            default:
                printf("Choix invalide. Veuillez réessayer.\n");
                break;
        }
    } while (choix_menu != 0);

    // Libération de la mémoire
    mpz_clear(n);
    mpz_clear(n_restant);
    for (size_t i = 0; i < capacite_facteurs; i++) {
        mpz_clear(liste_facteurs[i]);
        mpz_clear(liste_puissances[i]);
    }
    free(liste_facteurs);
    free(liste_puissances);

    return EXIT_SUCCESS;
}
