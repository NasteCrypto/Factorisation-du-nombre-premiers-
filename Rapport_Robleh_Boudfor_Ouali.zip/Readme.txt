Ce projet met en œuvre trois méthodes de factorisation d'entiers développé en langage C et utilise la bibliothèque GMP.

functions.h contient les déclarations des fonctions utilisées dans les différentes méthodes de factorisation. Il regroupe les prototypes pour la division successive, la méthode rho de Pollard et la méthode p-1 de Pollard.

functions.c implémente les fonctions définies dans functions.h . 

outils_factorisation.c est le programme principal qui exécute l’outil de factorisation interactif pour deuxième partie du projet.

 commande de compilation : 

 gcc -o outils_factorisation outils_factorisation.c functions.c -lgmp


