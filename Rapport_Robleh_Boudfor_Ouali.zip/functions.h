#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <gmp.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <limits.h>    

#define COMPOSE 0
#define PROBABP 1



/*Cette partie du code consiste à declarer les fonctions utlisées pour la premiere methode "divisions successives": test_miller_rabin, crible,ajouter_facteur_avec_exposant, Divisions */

// Déclaration de la fonction test_miller_rabin
bool test_miller_rabin(mpz_t n);

// Déclaration de la fonction Crible 
void crible(mpz_t limite, mpz_t **premiers, size_t *taille_premiers);


// Déclaration de la fonctions de factorisation

void ajouter_facteur_avec_exposant(const mpz_t factor, unsigned long exposant,
    mpz_t **liste_facteurs, mpz_t **liste_puissances, size_t *taille_facteurs, size_t *capacite_facteurs);

void Divisions(mpz_t n, mpz_t p_max, mpz_t *liste_facteurs, mpz_t *liste_puissances,
               size_t *taille_facteurs, size_t *capacite_facteurs);





/*Cette partie du code consiste à declarer les fonctions utlisées pour la deuxième methode "rho de Pollard": rho_pollard basique, rho_pollard_floyd , rho_pollard_Brent */

// Déclaration des fonctions de la méthode Rho de Pollard
int rho_pollard(mpz_t factor, const mpz_t n, const mpz_t c, unsigned long max_iter,
                unsigned long *success_count, unsigned long *total_attempts);

// Méthode Pollard Rho-Floyd (tortue/lièvre)
int rho_pollard_floyd(mpz_t factor, const mpz_t n, const mpz_t c, unsigned long max_iter,
                      unsigned long *success_count, unsigned long *total_attempts);

// Méthode de Brent pour la factorisation
void brent_factorization(mpz_t factor, const mpz_t n, const unsigned long iter_max, const unsigned long x0);





/*Cette partie du code consiste à declarer les fonctions utlisées pour la troisème methode "P_1 de Pollard":is_prime , pollard_pm1 , all_factors  */


int is_prime(const mpz_t n);

// Pollard p-1 amélioré
void pollard_pm1(const mpz_t n, mpz_t factor, unsigned long B1, unsigned long B2);

// Récupérer tous les facteurs : Permet de génerer tous les facteur via algorithme pollard_pm1
void all_factors(mpz_t n, mpz_t factors[], int *count, unsigned long B1, unsigned long B2);

#endif

