 //Première partie du projet 
 #include "functions.h"



/* Cette  première partie du code représente les fonctions utilisées pour la première méthode "divisions successives" : test_miller_rabin, crible, ajouter_facteur_avec_exposant, Divisions */




// ********************************************************************
// Pour le test de Miller-Rabin que nous allons utiliser dans le crible, nous avons fixé le nombre d'itérations à 25 comme seuil pour tester la primalité des nombres.
// Pour le crible (proche du crible d'Ératosthène), nous avons commencé par initialiser une liste de tous les nombres premiers jusqu'à 73. Ensuite, si un nombre n'est pas divisible, nous le faisons passer par le test de Miller-Rabin.
// Fonction de division successive
// Fonction "ajouter_facteur_avec_exposant" (que nous utiliserons pour la deuxième partie du projet) permet de copier tous les facteurs retournés par la division et de les stocker dans une liste.
// ********************************************************************



bool test_miller_rabin(mpz_t n) {
    const int A = 25; 
    if (mpz_even_p(n))
        return COMPOSE;

    mpz_t n_minus_1, d, a, res;
    mpz_inits(n_minus_1, d, a, res, NULL);
    mpz_sub_ui(n_minus_1, n, 1);

    unsigned int s = 0;
    mpz_set(d, n_minus_1);
    while (mpz_even_p(d)) {
        mpz_divexact_ui(d, d, 2);
        s++;
    }

    gmp_randstate_t state;
    gmp_randinit_mt(state);

    for (int i = 0; i < A; i++) {
        mpz_urandomm(a, state, n_minus_1);
        mpz_add_ui(a, a, 2);

        mpz_powm(res, a, d, n);
        if (mpz_cmp_ui(res, 1) == 0 || mpz_cmp(res, n_minus_1) == 0)
            continue;

        int is_composite = 1;
        for (unsigned int r = 1; r < s; r++) {
            mpz_powm_ui(res, res, 2, n);
            if (mpz_cmp(res, n_minus_1) == 0) {
                is_composite = 0;
                break;
            }
        }

        if (is_composite) {
            mpz_clears(n_minus_1, d, a, res, NULL);
            gmp_randclear(state);
            return COMPOSE;
        }
    }

    mpz_clears(n_minus_1, d, a, res, NULL);
    gmp_randclear(state);
    return PROBABP;
}



void crible(mpz_t limite, mpz_t **premiers, size_t *taille_premiers) {
    // Liste des petits premiers de 2 à 73
    const int petits_premiers[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29,
                                   31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73};
    const int taille_petits = sizeof(petits_premiers) / sizeof(petits_premiers[0]);

    // Allocation initiale de la liste des nombres premiers
    *premiers = malloc(mpz_get_ui(limite) * sizeof(mpz_t));
    if (!(*premiers)) {
        fprintf(stderr, "Erreur d'allocation mémoire\n");
        exit(EXIT_FAILURE);
    }
    *taille_premiers = 0;

    // Ajouter les petits premiers <= limite
    for (int i = 0; i < taille_petits && petits_premiers[i] <= mpz_get_ui(limite); i++) {
        mpz_init_set_ui((*premiers)[(*taille_premiers)++], petits_premiers[i]);
    }

    // Ajouter les nombres premiers de 75 à limite en testant avec Miller-Rabin
    mpz_t current;
    mpz_init_set_ui(current, 75);

    while (mpz_cmp(current, limite) <= 0) {
        if (test_miller_rabin(current)) { 
            mpz_init_set((*premiers)[(*taille_premiers)++], current);
        }
        mpz_add_ui(current, current, 1);
    }

    mpz_clear(current);
}



void ajouter_facteur_avec_exposant(const mpz_t factor, unsigned long exposant,
    mpz_t **liste_facteurs, mpz_t **liste_puissances, size_t *taille_facteurs, size_t *capacite_facteurs)
{

    for (size_t i = 0; i < *taille_facteurs; i++) {
        if (mpz_cmp((*liste_facteurs)[i], factor) == 0) {
            mpz_t tmp;
            mpz_init_set_ui(tmp, exposant);
            mpz_add((*liste_puissances)[i], (*liste_puissances)[i], tmp);
            mpz_clear(tmp);
            return;
        }
    }


    if (*taille_facteurs == *capacite_facteurs) {
        *capacite_facteurs *= 2;
        mpz_t *tmp_factors = realloc(*liste_facteurs, (*capacite_facteurs) * sizeof(mpz_t));
        mpz_t *tmp_puissances = realloc(*liste_puissances, (*capacite_facteurs) * sizeof(mpz_t));
        if (!tmp_factors || !tmp_puissances) {
            fprintf(stderr, "Erreur de réallocation mémoire dans ajouter_facteur_avec_exposant.\n");
            exit(EXIT_FAILURE);
        }
        *liste_facteurs = tmp_factors;
        *liste_puissances = tmp_puissances;

        for (size_t j = *taille_facteurs; j < *capacite_facteurs; j++) {
            mpz_init((*liste_facteurs)[j]);
            mpz_init((*liste_puissances)[j]);
        }
    }


    mpz_set((*liste_facteurs)[*taille_facteurs], factor);
    mpz_set_ui((*liste_puissances)[*taille_facteurs], exposant);
    (*taille_facteurs)++;
}


//la fonction Divisions successive

void Divisions(mpz_t n, mpz_t p_max, mpz_t *liste_facteurs, mpz_t *liste_puissances,
               size_t *taille_facteurs, size_t *capacite_facteurs)
{
    mpz_t *premiers;
    size_t taille_premiers = 0;
    crible(p_max, &premiers, &taille_premiers);

    for (size_t i = 0; i < taille_premiers; i++) {
        unsigned long exposant = 0;
        while (mpz_divisible_p(n, premiers[i])) {
            mpz_divexact(n, n, premiers[i]);
            exposant++;
        }
        if (exposant > 0) {
            ajouter_facteur_avec_exposant(premiers[i], exposant,
                &liste_facteurs, &liste_puissances, taille_facteurs, capacite_facteurs);
        }
    }

    if (mpz_cmp_ui(n, 1) != 0) {
        printf("\nFacteur restant : ");
        gmp_printf("%Zd\n", n);
        if (test_miller_rabin(n)) {
            printf("Facteur restant est premier et ajouté à la liste.\n");
            ajouter_facteur_avec_exposant(n, 1,
                &liste_facteurs, &liste_puissances, taille_facteurs, capacite_facteurs);
        }
    }

    for (size_t i = 0; i < taille_premiers; i++) {
        mpz_clear(premiers[i]);
    }
    free(premiers);
}




/* Cette deuxième partie du code représente les fonctions utilisées pour la deuxième méthode "Méthode des facteurs de Pollard" : rho_pollard basique, rho_pollard_floyd, rho_pollard_Brent. Ces méthodes servent à identifier les facteurs non triviaux d'un nombre. */



// Fonction f(x) = (x^2 + c) % n
void f(mpz_t result, const mpz_t x, const mpz_t c, const mpz_t n) {
    mpz_mul(result, x, x);     // result = x^2
    mpz_add(result, result, c); // result = x^2 + c
    mpz_mod(result, result, n); // result = (x^2 + c) % n
}


// Fonction pour calculer le PGCD
void gcd_wrap(mpz_t result, const mpz_t a, const mpz_t b) {
    mpz_gcd(result, a, b);
}


// Méthode Pollard-Rho

int rho_pollard(mpz_t factor, const mpz_t n, const mpz_t c,
                unsigned long max_iter, unsigned long *success_count, unsigned long *total_attempts)
{
    mpz_t x, y, d, diff;
    mpz_inits(x, y, d, diff, NULL);
    mpz_set_ui(x, 2);
    mpz_set_ui(y, 2);
    mpz_set_ui(d, 1);

    unsigned long iterations = 0;
    while (mpz_cmp_ui(d, 1) == 0 && iterations < max_iter) {
        f(x, x, c, n); // x = f(x)
        f(y, y, c, n); // y = f(y)
        f(y, y, c, n); // y = f(f(y))

        mpz_sub(diff, x, y);
        mpz_abs(diff, diff);
        gcd_wrap(d, diff, n);

        (*total_attempts)++;

        if (mpz_cmp_ui(d, 1) > 0 && mpz_cmp(d, n) < 0) {
            (*success_count)++;
            gmp_printf("Itération %lu : x = %Zd, y = %Zd, d = %Zd, Succès = %.2f%%\n",
                       iterations + 1, x, y, d,
                       ((double)(*success_count) / (*total_attempts)) * 100);
            mpz_set(factor, d);
            mpz_clears(x, y, d, diff, NULL);
            return 1;
        }
        iterations++;
    }

    mpz_clears(x, y, d, diff, NULL);
    return 0;
}


// Méthode Pollard-Rho-Floyd 
int rho_pollard_floyd(mpz_t factor, const mpz_t n, const mpz_t c,
                      unsigned long max_iter, unsigned long *success_count, unsigned long *total_attempts)
{
    mpz_t tortue, lievre, d, diff;
    mpz_inits(tortue, lievre, d, diff, NULL);
    mpz_set_ui(tortue, 2);
    mpz_set_ui(lievre, 2);
    mpz_set_ui(d, 1);

    unsigned long iterations = 0;
    while (mpz_cmp_ui(d, 1) == 0 && iterations < max_iter) {
        f(tortue, tortue, c, n);
        f(lievre, lievre, c, n);
        f(lievre, lievre, c, n);

        mpz_sub(diff, tortue, lievre);
        mpz_abs(diff, diff);
        gcd_wrap(d, diff, n);

        (*total_attempts)++;

        if (mpz_cmp_ui(d, 1) > 0 && mpz_cmp(d, n) < 0) {
            (*success_count)++;
            gmp_printf("Itération %lu : tortue = %Zd, lievre = %Zd, d = %Zd, Succès = %.2f%%\n",
                       iterations + 1, tortue, lievre, d,
                       ((double)(*success_count) / (*total_attempts)) * 100);
            mpz_set(factor, d);
            mpz_clears(tortue, lievre, d, diff, NULL);
            return 1;
        }
        iterations++;
    }

    mpz_clears(tortue, lievre, d, diff, NULL);
    return 0;
}


// Méthode de Brent pour la factorisation

void brent_factorization(mpz_t factor, const mpz_t n,
                         const unsigned long iter_max, const unsigned long x0)
{
    mpz_t x, y, ys, q, g, temp;
    unsigned long r = 1, m = 32, k;
    mpz_inits(x, y, ys, q, g, temp, NULL);
    mpz_set_ui(q, 1);
    mpz_set_ui(x, x0);
    mpz_set_ui(y, x0);
    mpz_set_ui(factor, 0); 

    while (1) {
        // Étape 1 : Avancer y de r étapes
        for (unsigned long i = 0; i < r; i++) {
            mpz_mul(x, y, y);     // x = y²
            mpz_add_ui(x, x, 1);  // x = y² + 1
            mpz_mod(y, x, n);     // y = (y² + 1) mod n
        }
        mpz_set(ys, y);

        // Étape 2 : Tester m étapes ou jusqu'à trouver un facteur
        for (k = 0; k < r; k += m) {
            for (unsigned long i = 0; i < m && i < r - k; i++) {
                mpz_mul(x, y, y);     // y = y²
                mpz_add_ui(x, x, 1);  // y = y² + 1
                mpz_mod(y, x, n);     // y = (y² + 1) mod n

                mpz_sub(temp, ys, y); // temp = |ys - y|
                mpz_abs(temp, temp);
                mpz_mul(q, q, temp);
                mpz_mod(q, q, n);
            }
            mpz_gcd(g, q, n);
            if (mpz_cmp_ui(g, 1) > 0 && mpz_cmp(g, n) < 0) {
                mpz_set(factor, g);
                mpz_clears(x, y, ys, q, g, temp, NULL);
                return;
            }
        }
        r *= 2;
        if (mpz_cmp(g, n) == 0) {
            do {
                mpz_mul(x, ys, ys);     // ys = ys²
                mpz_add_ui(x, x, 1);    // ys = ys² + 1
                mpz_mod(ys, x, n);      // ys = (ys² + 1) mod n

                mpz_sub(temp, x, ys);
                mpz_abs(temp, temp);
                mpz_gcd(g, temp, n);
            } while (mpz_cmp_ui(g, 1) <= 0);
            if (mpz_cmp(g, n) < 0) {
                mpz_set(factor, g);
                mpz_clears(x, y, ys, q, g, temp, NULL);
                return;
            }
        }
    }
    mpz_clears(x, y, ys, q, g, temp, NULL);
    mpz_set_ui(factor, 0);
}




/* Cette troisième partie du code concerne les fonctions utilisées pour la troisième méthode "P-1 de Pollard" : is_prime, pollard_pm1, all_factors. Ces fonctions sont destinées à la détection de facteurs premiers en utilisant des approches de factorisation avancées. */



// Test de primalité 
int is_prime(const mpz_t n) {
    return (mpz_probab_prime_p(n, 25) > 0);
}


// Méthode Pollard p-1 
void pollard_pm1(const mpz_t n, mpz_t factor, unsigned long B1, unsigned long B2) {
    mpz_set_ui(factor, 0); 
    if (mpz_cmp_ui(n, 2) <= 0)
        return;

    mpz_t a, d, temp;
    mpz_inits(a, d, temp, NULL);
    mpz_set_ui(a, 2);

    // Phase 1 : jusqu'à B1
    mpz_gcd(d, a, n);
    if (mpz_cmp_ui(d, 1) != 0) {
        mpz_set(factor, d);
        goto clear_and_return;
    }
    for (unsigned long k = 2; k <= B1; k++) {
        mpz_set_ui(temp, k);
        mpz_powm(a, a, temp, n);
    }
    mpz_sub_ui(temp, a, 1);
    mpz_gcd(d, temp, n);
    if (mpz_cmp_ui(d, 1) != 0 && mpz_cmp(d, n) != 0) {
        mpz_set(factor, d);
        goto clear_and_return;
    }
    // Phase 2 : entre B1 et B2
    for (unsigned long k = B1 + 1; k <= B2; k++) {
        mpz_set_ui(temp, k);
        mpz_powm(a, a, temp, n);
        mpz_sub_ui(temp, a, 1);
        mpz_gcd(d, temp, n);
        if (mpz_cmp_ui(d, 1) != 0 && mpz_cmp(d, n) != 0) {
            mpz_set(factor, d);
            goto clear_and_return;
        }
    }

clear_and_return:
    mpz_clears(a, d, temp, NULL);
}


// Récupérer tous les facteurs avec deux bornes 
void all_factors(mpz_t n, mpz_t factors[], int *count, unsigned long B1, unsigned long B2) {
    if (mpz_cmp_ui(n, 1) <= 0)
        return;

    if (is_prime(n)) {

        mpz_set(factors[*count], n);
        (*count)++;
        return;
    }

    mpz_t f;
    mpz_init(f);
    pollard_pm1(n, f, B1, B2);
    if (mpz_cmp_ui(f, 0) == 0 || mpz_cmp(f, n) == 0) {
        mpz_clear(f);
        return;
    }
    all_factors(f, factors, count, B1, B2);
    mpz_divexact(n, n, f);
    all_factors(n, factors, count, B1, B2);
    mpz_clear(f);
}

